# Đề bài:
---
>  Hãy viết một chương trình C++ để tìm chuỗi con không lặp lại dài nhất trong một chuỗi đã cho
# Yêu cầu:
* Input:
>  Một dòng duy nhất có chứa chuỗi x bất kì không chứa space(" ")
* Output:
> Một dòng duy nhất chứa chuỗi con không lặp lại dài nhất trong một chuỗi đã cho
# Ví dụ mẫu:
|       **Input**      | **Output**           |
|:--------------------:|----------------------|
| abcdfghje            | abcdfghje            |
| asdghasss |                  s    |
