# Đề bài:
---
>  Cho một mảng gồm n số nguyên, hãy tìm ra tỷ lệ số âm, dương và số không (0) trong mảng 
# Yêu cầu:
* Input:
>  Dòng đầu một số n (1 $$\leq$$ n $$\leq$$ 100)
Dòng thứ hai một dãy số x~n~ (-10^3^ $$\leq$$ x~n~ $$\leq$$ 10^3^)
* Output:
> Ba dòng mỗi dòng lần lượt là kết quả tương ứng: tỷ lệ số âm, dương và số 0
Các kết quả thập phân được làm tròn đến chữ số thập phân thứ 6 sau dấu chấm.
# Ví dụ mẫu:
# **Input**
> 5
0 0 -1 1 1
# **Output**
>0.400000
0.200000
0.400000