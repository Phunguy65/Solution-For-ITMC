# Đề bài:
---
> Cho một mảng gôm ==2n== phần tử: [***x~1~, x~2~, ...,x~n~, y~1~, y~2~, ..., y~n~***] hãy in ra một mảng theo quy tắc sau: [***x~1~, y~1~, x~2~, y~2~, ..., x~n~, y~n~***] 
# Yêu cầu:
* Input:
> Dòng đầu: n (1 $$\leq$$ n $$\leq$$ 5000)
Dòng thứ hai: [x~1~, x~2~, ...,x~n~, y~1~, y~2~, ..., y~n~] (-20 $$\leq$$ x~n~,y~n~ $$\leq$$ 1800000 )
* Output:
> Một mảng: [x~1~, y~1~, x~2~, y~2~, ..., x~n~, y~n~] 
# Ví dụ mẫu:
|       **Input**      | **Output**           |
|:--------------------:|----------------------|
| 10                   | 1 6 2 7 3 8 4 9 5 10 |
| 1 2 3 4 5 6 7 8 9 10 |                      |
